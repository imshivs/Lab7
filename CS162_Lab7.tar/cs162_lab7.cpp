#include "cs162_list.h"

//Start in Step 3 by uncommenting out the code to create 
//a list object and build it!
int main()
{
    //Create an object of class list
    //list my_list;
    list my_list;
    //Call the build function to create a Linear Linked List
    my_list.build();
    //(The build member function has already been written)
    //my_list.build();


    //Place your code here to call the functions for Lab #7
    my_list.display_all();
    int count = my_list.count_first();
    cout << count << endl;

    bool multiple_of_last = false;
    multiple_of_last = my_list.find_last();

    if(multiple_of_last)
        cout << "duplicates of last number" << endl;
    else
        cout << "no duplicates of last number" << endl;
    
    return 0;
}


