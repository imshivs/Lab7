#include "cs162_list.h"

//These are the functions you will be writing
//Everything else has already been written for you!

//Constructor
list::list()
{
     //Step 3 - Implement the constructor herei
     head = NULL;

}


//Display all items in a linear linked list
void list::display_all()
{
    node * current = head;
    int count = 0;
     //Step 5 - Implement the display_all function here
     while(current)
     { 
         cout << current -> data << endl; 
         current = current -> next;
     }

}

//Count the number of times the first node's data appears
//in the list, and return that count.
int list::count_first()
{
     //Step 6 - Implement the count_first here
     //(remember to return the count!
     node * current = head;
     node * first = head;
     int count = 0;
     cout << "hi" << endl;
     while(current)
     {
         if(current -> data == first -> data)
             count++;
         
         current = current -> next;
     }
    
     return count;

}

//Return true if the last node's data appears
//in the list more than once.
bool list::find_last()
{
    //Step 7-8 - Place your code here
    node * current = head;
    node * last = NULL;

    while(current)
    {
        if(current -> next == NULL)
            last = current;
        current = current -> next;
    } 
    
    current = head;

    while(current){
        if(current -> data == last -> data)
            return true;
        current = current -> next;
    }
    
    return false;

}
